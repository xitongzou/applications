## Running the app

First, `npm install` to install all the node modules, then `npm start` to run the app.